#ifndef VEHICLETYPE_H
#define VEHICLETYPE_H

enum class VehicleType 
{
    REGULAR,TRANSPORT
};

#endif // VEHICLETYPE_H
