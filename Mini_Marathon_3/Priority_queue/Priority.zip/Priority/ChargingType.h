#ifndef CHARGINGTYPE_H
#define CHARGINGTYPE_H

enum class ChargingType 
{
    AC,DC_FAST_CHARGE
};

#endif // CHARGINGTYPE_H
